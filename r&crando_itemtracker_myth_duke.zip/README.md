
Myth197 and DukeDragon28's Ratchet and Clank Randomizer Tracker

----- INSTALATION--------
To use it, place the files in C:\Users__\Documents\EmoTracker\packs
then reload emotracker and then select it from installed packages.

